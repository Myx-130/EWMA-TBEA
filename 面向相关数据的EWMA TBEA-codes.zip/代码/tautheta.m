function tautheta()
    tau = (0:0.1:0.9)'; % 列向量
    for i = 1:10
        taui = tau(i);
        fprintf('%3.1f & %5.2f & %5.2f & %5.2f \\\\\n', taui, francktheta(taui), claytontheta(taui), gumbeltheta(taui));
    end
end