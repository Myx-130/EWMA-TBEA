clc;
clear;
tic;

arl0 = 100;
rho1 = 1;
rho2 = 1;
lb = 0;
ub = 2.25;
muX0 = 5001.1;
muT0 = 61.1;
lam = [0.1];

% 启动并行
parpool;  % 默认开启与您系统中的核心数相同的并行池

% 使用 parfor 替代 for 循环
parfor i = 1:length(lam)
    [UCLd(i), ARL0(i), flag(i)] = optuEWMAtbealam(lam(i), arl0, rho1, rho2, muX0, muT0, lb, ub);
end

out = [UCLd' ARL0' flag'];
toc;

% 关闭并行池
delete(gcp);  % 关闭并行池