function CDF = cdfZ(UCL, C, ZZ, disX, muX0, sdX0, disT, muT0, sdT0, tau, rho1, rho2)
    
    N = 10000000;
    switch C
        case 8
            x = rand(N, 1);
            w = rand(N, 1);
            theta = claytontheta(tau);
            t = (x.^(-theta) .* (w.^(-theta/(1 + theta)) - 1) + 1).^(-1/theta);
        case 9
            x = rand(N, 1);
            w = rand(N, 1);
            theta = francktheta(tau);
            t = -(1/theta) .* log(1 + (w .* (1 - exp(-theta))) ./ (w .* (exp(-theta .* x) - 1) - exp(-theta .* x)));
        case 10
            v1 = rand(N, 1);
            v2 = rand(N, 1);
            theta = gumbeltheta(tau);
            w = 1e-6 * ones(N, 1);
            while true
                delta = (w .* (1 - log(w) / theta) - v2) ./ (1 - log(w) / theta - 1/theta);
                if all(abs(delta) < 1e-6)
                    break;
                else
                    w = w - delta; 
                end
            end
            x = exp(v1.^(1/theta) .* log(w));
            t = exp((1 - v1).^(1/theta) .* log(w));
    end

    % 计算 X 和 T
    X = idfTX(x, disX, rho1 * muX0, sdX0);
    T = idfTX(t, disT, rho2 * muT0, sdT0);

    % 归一化
    X1 = X ./ muX0;
    T1 = T ./ muT0;

    % 根据 ZZ 的值计算 Z
    switch ZZ
        case 5
            Z = X1 - T1;
        case 6
            Z = X1 ./ T1;
        case 7
            Z = X1 + (1 ./ T1);
    end  

    Z = sort(Z); % 排序
    CDF = sum(Z <= UCL) / N; % 计算 CDF
end