function d = debie(theta)
    % 内部函数debie_
    function y = debie_(t)
        y = t ./ (exp(t) - 1);
    end

    % 计算d的值
    d = integral(@debie_, 0, theta) / theta;
end