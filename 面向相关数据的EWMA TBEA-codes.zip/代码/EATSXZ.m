function EATS = EATSXZ(C, ZZ, disX, muX0, sdX0, disT, muT0, sdT0, tau, ATS0)

    % 计算 UCL
    UCL = uclZ(C, ZZ, disX, muX0, sdX0, disT, muT0, sdT0, tau, ATS0);
    muT1 = muT0;

    % 定义 dX 范围
    dX = 1.1:0.1:2;
    ATS = zeros(1, 10); % 初始化 ARL 数组

    % 循环计算 ARL
    for i = 1:10
        muX1 = dX(i) * muX0;
        bet = cdfZ(C, ZZ, UCL, disX, muX0, sdX0, disT, muT1, sdT0, tau, muX1);
        ATS(i) = muT1 / (1 - bet);
    end

    % 计算 EARL
    EATS = mean(ATS);
end