function ARL = rlUewmatbeaFSgw(lam, UCLe, rho1, rho2, muX0, muT0)
    if (lam <= 0) || (lam > 1)
        error('argument ''lam'' must be in (0,1]');
    end

    % 参数设置
    mu0 = 10;
    sigma0 = 1;
    sigma1 = 1;
    muX1 = rho1 * muX0;
    muT1 = rho2 * muT0;
    aX1 = (muX1 / sigma0)^2;
    bX1 = muX1 / aX1;
    options = optimset('Display', 'off');
    aT1 = fsolve(@(aT1) abfrommusdW_T(aT1, muT1, sigma1), 2, options);
    bT1 = muT1 / gamma(1 / aT1 + 1);
    function z = abfrommusdW_T(aT1, muT1, sigma1)
        if aT1 <= 0, z = 1e4;
            else, z = muT1^2 * (gamma(2 / aT1 + 1) / gamma(1 / aT1 + 1)^2 - 1) - sigma1^2;
        end
    end

    % 设置蒙特卡洛仿真次数
    rep = 10^5;
    RL = zeros(rep, 1);
    Z0 = 0.0161;

    % Frank Copula 的相关性参数
    tau = 0.8; % 根据需要调整 Kendall's tau 值
    theta = francktheta(tau); % 计算 Frank Copula 的参数

    for i = 1:rep
        j = 1;

        % 生成相关的随机变量 X1 和 T1 使用 Frank Copula
        [u, v] = frank_copula_samples(theta, 1);
        X1 = gaminv(u, aX1, bX1) / mu0;
        T1 = wblinv(v, bT1, aT1) / mu0;

        % 计算 X 和 Z
        X = X1 - T1;
        Z = lam * X + (1 - lam) * Z0;
        Z = max(Z0, Z);

        while true
            if Z > UCLe
                RL(i) = j;
                break;
            end

            % 生成相关的随机变量 X1 和 T1 使用 Frank Copula
            [u, v] = frank_copula_samples(theta, 1);
            X1 = gaminv(u, aX1, bX1) / mu0;
            T1 = wblinv(v, bT1, aT1) / mu0;

            % 计算 X 和 Z
            X = X1 - T1;
            Z = lam * X + (1 - lam) * Z;
            Z = max(Z0, Z);
            j = j + 1;
        end
    end

    % 计算结果
    ARL = mean(RL);

    % 输出结果
    fprintf('ARL: %.4f\n', ARL);
end

% 辅助函数：生成 Frank Copula 样本
function [u, v] = frank_copula_samples(theta, n)
    % Frank Copula 的生成公式
    % theta 是 Copula 参数
    % n 是样本数量
    
    u = rand(n, 1);
    w = rand(n, 1);
    
    % 计算 Frank Copula 的相关样本
    v = -(1/theta) .* log(1 + (w .* (1 - exp(-theta))) ./ (w .* (exp(-theta .* u) - 1) - exp(-theta .* u)));
end