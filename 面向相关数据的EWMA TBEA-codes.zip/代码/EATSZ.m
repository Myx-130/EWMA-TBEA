function EATS = EATSZ(C, ZZ, disX, muX0, sdX0, disT, muT0, sdT0, tau, ATS0)

    UCL = uclZ(C, ZZ, disX, muX0, sdX0, disT, muT0, sdT0, tau, ATS0);
    
    dX = 1.1:0.1:2;
    dT = 0.5:0.05:0.95;
    
    ATS = zeros(10, 10); 

    for iX = 1:10
        muX1 = dX(iX) * muX0;
        for iT = 1:10
            muT1 = dT(iT) * muT0;
            bet = cdfZ(C, ZZ, UCL, disX, muX0, sdX0, disT, muT0, sdT0, tau, muX1, muT1);
            ATS(iX, iT) = muT1 / (1 - bet);
        end
    end

    EATS = mean(ATS(:)); 
end