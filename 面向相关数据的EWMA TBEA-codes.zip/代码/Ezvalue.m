 integrand = @(z)(z.*pdfZ(9, 5, z, 4, 5001.1, 1166.2, 1, 61.1, 15.59, 0.4657, 5001.1, 61.1));
Ez = integral(integrand, eps, 10);