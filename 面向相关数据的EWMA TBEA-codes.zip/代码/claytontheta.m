function theta = claytontheta(tau)
    theta = 2 * tau / (1 - tau);
end