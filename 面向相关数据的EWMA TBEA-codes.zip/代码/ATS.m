function ATS0 = ATS(C, ZZ, UCL, disX, muX0, sdX0, disT, muT0, sdT0, tau, muX1, muT1)

alpha = 1 - cdfZ(C, ZZ, UCL, disX, muX0, sdX0, disT, muT0, sdT0, tau, muX1, muT1)
ATS0 = muT0 / alpha