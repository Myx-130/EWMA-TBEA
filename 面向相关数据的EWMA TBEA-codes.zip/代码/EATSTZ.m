function EATS = EATSTZ(C, ZZ, disX, muX0, sdX0, disT, muT0, sdT0, tau, ATS0)

    % 计算 UCL
    UCL = uclZ(C, ZZ, disX, muX0, sdX0, disT, muT0, sdT0, tau, ATS0);
    muX1 = muX0;

    % 定义 dT 范围
    dT = 0.5:0.05:0.95;
    ATS = zeros(1, 10); % 初始化 ARL 数组

    % 循环计算 ARL
    for i = 1:10
        muT1 = dT(i) * muT0;
        bet = cdfZ(C, ZZ, UCL, disX, muX0, sdX0, disT, muT0, sdT0, tau, muX1, muT1);
        ATS(i) = muT1 / (1 - bet);
    end

    % 计算 EARL
    EATS = mean(ATS);
end