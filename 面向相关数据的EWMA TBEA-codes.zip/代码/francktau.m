function tau = francktau(theta)
    tau = 1 + 4 * (debie(theta) - 1) / theta;
end