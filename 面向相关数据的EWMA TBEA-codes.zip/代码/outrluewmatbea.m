% 运行代码
clc;
clear;
tic;

lam = 1;
UCLe = 2.1847;
rho1 = [1 1.01 1.02 1.03 1.04 1.05 1.06 1.07 1.08 1.09 2];
rho2 = [1 0.99 0.98 0.97 0.96 0.95 0.94 0.93 0.92 0.91 0.9];
ARL = zeros(length(lam), length(rho1), length(rho2));

for i = 1:length(lam)
    for p = 1:length(rho1)
        for q = 1:length(rho2)
            ARL(i, p, q) = rlUewmatbeaFSgg(lam(i), UCLe(i), rho1(p), rho2(q), 10, 10);
        end
    end
end

out = ARL;
toc;

% 将结果写入 Excel 文件
out2D = reshape(out, [], size(out, 3)); % 展平三维数组为二维数组
filename = 'ARL_results.xlsx'; % Excel 文件名
writematrix(out2D, filename); % 写入文件

disp(['结果已保存到 ' filename]);