% ===== 文件选择对话框 =====
[filename, filepath] = uigetfile({'*.xlsx;*.xls', 'Excel文件 (*.xlsx, *.xls)'},...
                               '请选择数据文件');
if isequal(filename, 0)
    error('用户取消选择，操作已终止');
end
fullpath = fullfile(filepath, filename);

% ===== 数据读取 =====
try
    data = readtable(fullpath, 'Range', 'A:B');
    T = data{:,1}; % 横轴数据
    X = data{:,2}; % 纵轴数据
catch
    error('数据读取失败，请检查：\n1. 文件格式\n2. A/B列数据类型');
end

% ===== 数据清洗 =====
valid_idx = ~isnan(T) & ~isnan(X);
T = T(valid_idx);
X = X(valid_idx);

% ===== 阶段划分 =====
total_points = length(T);
if total_points < 44
    error('数据不足44行，当前数据行数：%d', total_points);
end

phase1_idx = 1:30;    % 第一阶段（前30行）
phase2_idx = 31:44;   % 第二阶段（后14行）

% ===== 专业绘图设置 =====
figure('Color','w', 'Position', [100 100 800 600], 'Name','数据可视化');
hold on;

% 第一阶段：红色实心圆（带黑边）
scatter(T(phase1_idx), X(phase1_idx),...
    90,... % 标记大小
    'o',...
    'MarkerFaceColor', [0 0 0],... % 红色填充
    'MarkerEdgeColor', [0 0 0],... % 黑色边框
    'LineWidth', 1.2);

% 第二阶段：黑色空心圆
scatter(T(phase2_idx), X(phase2_idx),...
    90,...
    'o',...
    'MarkerFaceColor', 'none',...
    'MarkerEdgeColor', [0 0 0],...
    'LineWidth', 1.2);

% ===== 坐标轴设置 =====
set(gca, 'FontSize', 12,...
        'LineWidth', 1.5,...
        'XGrid', 'on',...
        'YGrid', 'on',...
        'GridColor', [0.85 0.85 0.85],...
        'GridAlpha', 0.6);

xlim([0 100]);
ylim([0 9000]);
xlabel('{\it T}', 'FontSize', 14, 'FontWeight', 'bold');
ylabel('{\it X}', 'FontSize', 14, 'FontWeight', 'bold');

% ===== 保存图像 =====
saveas(gcf, 'analysis_result.png');
disp('>> 图像已保存为 analysis_result.png');
hold off;