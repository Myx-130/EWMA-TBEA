clear; clc;
data0 = load('EWMA.txt');
UCL = 2.6168;

% 增加图表的尺寸
figure('Position', [100 100 1000 500]); % 宽度1000, 高度400

x = 1:length(data0); % 使用所有数据点的索引
plot(x, data0, 'o-', 'MarkerSize', 6, 'LineWidth', 1.2); % 使用较小的点和细线

hold on;
plot([1, length(data0)], [UCL, UCL], 'r--'); % 绘制UCL线，使用红色虚线

% 调整文本标签的位置和格式
text(13, UCL - 0.15, 'UCL=2.6168', ...
    'Interpreter', 'latex', 'FontSize', 12, 'HorizontalAlignment', 'center');

% 设置坐标轴属性
set(gca, 'xlim', [1 max(x)]); % 自动调整x轴的范围
set(gca, 'xtick', 1:1:max(x)); % 每隔10个点设置一个刻度
set(gca, 'ylim', [1 4]);
set(gca, 'ytick', 1:0.2:4);

% 设置坐标轴标签和标题
xlabel('$t$', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('$E_t^+$', 'Interpreter', 'latex', 'FontSize', 12);

% 设置坐标轴框和刻度方向
set(gca, 'box', 'off');
ax = gca;
ax.XAxis.TickDirection = 'out';
ax.YAxis.TickDirection = 'out';

hold off;