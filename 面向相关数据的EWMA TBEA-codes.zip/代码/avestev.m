% ===== 文件选择对话框 =====
[filename, filepath] = uigetfile(...
    {'*.xlsx;*.xls', 'Excel文件 (*.xlsx, *.xls)';  % 支持Excel格式
     '*.csv;*.txt', '文本文件 (*.csv, *.txt)';    % 支持文本格式
     '*.*', '所有文件 (*.*)'},...
    '请选择数据文件');

if isequal(filename, 0)
    error('用户取消选择，操作已终止');
end
filepath = fullfile(filepath, filename);

% ===== 数据读取 =====
try
    % 根据文件类型选择读取方式
    [~, ~, ext] = fileparts(filename);
    switch lower(ext)
        case {'.xlsx', '.xls'}
            data = readmatrix(filepath);  % 读取Excel数值数据
        case {'.csv', '.txt'}
            data = readmatrix(filepath);  % 读取文本数值数据
        otherwise
            error('不支持的文件格式: %s', ext);
    end
    
    % 将数据转换为向量（自动展平多维数据）
    data_vector = data(:);
    
catch ME
    error('数据读取失败: %s\n可能原因:\n1. 文件包含非数值数据\n2. 文件格式错误', ME.message);
end

% ===== 数据验证 =====
if isempty(data_vector)
    error('文件没有有效数值数据');
end

% ===== 计算统计量 =====
data_mean = mean(data_vector, 'omitnan');  % 忽略NaN计算均值
data_std = std(data_vector, 'omitnan');    % 计算样本标准差

% ===== 结果显示 =====
fprintf('\n===== 统计分析结果 =====\n');
fprintf('数据量: %d 个\n', numel(data_vector));
fprintf('平均值: %.4f\n', data_mean);
fprintf('标准差: %.4f\n', data_std);
fprintf('最小值: %.4f\n', min(data_vector));
fprintf('最大值: %.4f\n', max(data_vector));
fprintf('==========================\n');

% ===== 可视化（可选）=====
figure('Color','w', 'Name','数据分布');
histogram(data_vector, 15, 'FaceColor', [0.2 0.4 0.6], 'EdgeColor', 'w');
xlabel('数据值', 'FontSize', 12);
ylabel('频数', 'FontSize', 12);
title(sprintf('数据分布 (μ=%.2f, σ=%.2f)', data_mean, data_std), 'FontSize', 14);
grid on;