function theta = gumbeltheta(tau)
    theta = 1 / (1 - tau);
end