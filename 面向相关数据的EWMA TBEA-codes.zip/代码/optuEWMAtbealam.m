function [UCLd,ARL0,flag]=optuEWMAtbealam(lam,arl0,rho1,rho2,muX0, muT0,lb,ub)
%------lam是EWMA权重，针对lam，采用二分法找出EWMA TBEA-UCL
tor=1;

flag=0;
while true
    UCLe=(lb+ub)/2;
    ARL = examplerlFSwg(lam, UCLe, rho1, rho2, muX0, muT0);
    if (ARL<arl0+tor) && (ARL>arl0-tor)
        UCLd=UCLe;
        ARL0=ARL;
        break;
    elseif ARL<=arl0-tor
        lb=UCLe;
    else
        ub=UCLe;
    end
    flag=flag+1;
    if flag>20
        UCLd=UCLe;
        ARL0=ARL;
        break;
    end
end
end