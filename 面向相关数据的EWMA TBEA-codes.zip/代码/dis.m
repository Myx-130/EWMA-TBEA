% ===== 文件选择对话框 =====
[filename, filepath] = uigetfile({'*.xlsx;*.xls', 'Excel文件 (*.xlsx, *.xls)'}, '选择数据文件');
if isequal(filename, 0)
    error('用户取消选择');
end
fullpath = fullfile(filepath, filename);

% ===== 数据读取与预处理 =====
data = readmatrix(fullpath, 'Range', 'A:A'); % 读取A列数据
data = data(~isnan(data) & data > 0);       % 删除缺失值和负值
if isempty(data)
    error('数据无效：无正数值数据');
end
data_sorted = sort(data);
n = length(data_sorted);

% ===== 分布拟合与KS距离计算 =====
% 初始化结果存储
dist_names = {'正态分布', 'Weibull分布', 'Gamma分布'};
ks_stats = zeros(1,3);

% 1. 正态分布拟合
pd_normal = fitdist(data, 'Normal');
cdf_normal = normcdf(data_sorted, pd_normal.mu, pd_normal.sigma);
f_emp = (1:n)'/n;
D_plus = max(f_emp - cdf_normal);
D_minus = max(cdf_normal - (0:n-1)'/n);
ks_stats(1) = max(D_plus, D_minus);

% 2. Weibull分布拟合
pd_weibull = fitdist(data, 'Weibull');
cdf_weibull = wblcdf(data_sorted, pd_weibull.A, pd_weibull.B);
D_plus = max(f_emp - cdf_weibull);
D_minus = max(cdf_weibull - (0:n-1)'/n);
ks_stats(2) = max(D_plus, D_minus);

% 3. Gamma分布拟合
pd_gamma = fitdist(data, 'Gamma');
cdf_gamma = gamcdf(data_sorted, pd_gamma.a, pd_gamma.b);
D_plus = max(f_emp - cdf_gamma);
D_minus = max(cdf_gamma - (0:n-1)'/n);
ks_stats(3) = max(D_plus, D_minus);

% ===== 结果输出 =====
fprintf('\n===== KS距离分析结果 =====\n');
fprintf('%-12s: KS距离\n', '分布类型');
fprintf('%-12s: %.4f\n', dist_names{1}, ks_stats(1));
fprintf('%-12s: %.4f\n', dist_names{2}, ks_stats(2));
fprintf('%-12s: %.4f\n', dist_names{3}, ks_stats(3));

[~, idx] = min(ks_stats);
fprintf('\n结论：数据最符合【%s】(最小KS距离=%.4f)\n', dist_names{idx}, ks_stats(idx));