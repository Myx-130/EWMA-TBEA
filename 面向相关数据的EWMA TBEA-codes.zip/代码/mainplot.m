clc;
clear; 
close all
load Z
z = [0:0.01:2];
y = cdfZ(9, 6, z, 1, 10, 1, 1, 10, 1, 0.8, 10,10);

figure(1)
grid on
xlabel('z')
ylabel('Empirical CDF')

plot(z,y,"b-")
hold on
ecdf(Z)