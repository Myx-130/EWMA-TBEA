function x = idfTX(y, dis, mu, sd)
    % 1为Gamma分布
    % 2为Lognormal分布
    % 3为Normal分布
    % 4为Weibull分布
    % 获取参数a和b
    [a, b] = abfrommusd(dis, mu, sd);
    % 根据分布类型选择相应的IDF函数

    y = double(y); % 确保 y 是双精度
    a = double(a); % 确保 a 是双精度
    b = double(b); % 确保 b 是双精度

    switch dis
        case 1
            x = gaminv(y, a, b);
        case 2
            x = logninv(y, a, b);
        case 3
            x = norminv(y, a, b);
        case 4
            x = wblinv(y, b, a);
    end
end