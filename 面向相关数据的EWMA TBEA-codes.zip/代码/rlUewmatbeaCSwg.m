function ARL = rlUewmatbeaCSwg(lam, UCLe, rho1, rho2, muX0, muT0)
    if (lam <= 0) || (lam > 1)
        error('argument ''lam'' must be in (0,1]');
    end

    % 参数设置
    mu0 = 10;
    mu1 = 10;
    sigma0 = 1;
    sigma1 = 1;
    muX1 = rho1 * muX0;
    muT1 = rho2 * muT0;
    options = optimset('Display', 'off');
    aX1 = fsolve(@(aX1) abfrommusdW_X(aX1, muX1, sigma0), 2, options);
    bX1 = muX1 / gamma(1 / aX1 + 1);
    function z = abfrommusdW_X(aX1, muX1, sigma0)
        if aX1 <= 0, z = 1e4;
            else, z = muX1^2 * (gamma(2 / aX1 + 1) / gamma(1 / aX1 + 1)^2 - 1) - sigma0^2;
        end
    end
    aT1 = (muT1 / sigma1)^2;
    bT1 = muT1 / aT1;

    % 设置蒙特卡洛仿真次数
    rep = 10^5;
    RL = zeros(rep, 1);
    Z0 = 2.01;

    % Clayton Copula 的相关性参数
    tau = 0.8; % 根据需要调整 Kendall's tau 值
    theta = claytontheta(tau); % 计算 Clayton Copula 的参数

    for i = 1:rep
        j = 1;

        % 生成相关的随机变量 X1 和 T1 使用 Clayton Copula
        [u, v] = clayton_copula_samples(theta, 1);
        X1 = wblinv(u, bX1, aX1) / mu0;
        T1 = gaminv(v, aT1, bT1) / mu1;

        % 计算 X 和 Z
        X = X1 + 1 / T1;
        Z = lam * X + (1 - lam) * Z0;
        Z = max(Z0, Z);

        while true
            if Z > UCLe
                RL(i) = j;
                break;
            end

            % 生成相关的随机变量 X1 和 T1 使用 Clayton Copula
            [u, v] = clayton_copula_samples(theta, 1);
            X1 = wblinv(u, bX1, aX1) / mu0;
            T1 = gaminv(v, aT1, bT1) / mu1;

            % 计算 X 和 Z
            X = X1 + 1 / T1;
            Z = lam * X + (1 - lam) * Z;
            Z = max(Z0, Z);
            j = j + 1;
        end
    end

    % 计算结果
    ARL = mean(RL);

    % 输出结果
    fprintf('ARL: %.4f\n', ARL);
end

% 辅助函数：生成 Clayton Copula 样本
function [u, v] = clayton_copula_samples(theta, n)
    % 生成 n 个独立均匀样本
    u = rand(n, 1);
    w = rand(n, 1);
    
    % 使用 Clayton Copula 的公式生成相关样本
    v = (u.^(-theta) .* (w.^(-theta / (1 + theta)) - 1) + 1).^(-1 / theta);
end