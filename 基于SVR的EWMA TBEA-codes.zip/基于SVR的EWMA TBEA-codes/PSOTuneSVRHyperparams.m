function bestParams = PSOTuneSVRHyperparams(X, y, opts)

n = size(X,1);
idx = randperm(n);

nTrain = round(0.8 * n);
tr = idx(1:nTrain);
va = idx(nTrain+1:end);

Xtr = X(tr,:);
ytr = y(tr);
Xva = X(va,:);
yva = y(va);

% 计算类别权重（平衡IC和OC）
wIC = 1 / sum(ytr == 0);
wOC = 1 / sum(ytr == 1);
weights = zeros(size(ytr));
weights(ytr == 0) = wIC;
weights(ytr == 1) = wOC;
weights = weights / sum(weights) * length(weights);  % 归一化

% 参数范围
VarMin = [0.5, 0.0001, -1.5];
VarMax = [3,   0.1,    1.5];
nVar = 3;

MaxIt = opts.pso.MaxIt;
nPop  = opts.pso.nPop;
w     = opts.pso.w;
wdamp = opts.pso.wdamp;
c1    = opts.pso.c1;
c2    = opts.pso.c2;

VelMax = 0.2 * (VarMax - VarMin);
VelMin = -VelMax;

empty_particle.Position = [];
empty_particle.Cost = [];
empty_particle.Velocity = [];
empty_particle.Best.Position = [];
empty_particle.Best.Cost = [];

particle = repmat(empty_particle, nPop, 1);
BestSol.Cost = inf;

for i = 1:nPop
    particle(i).Position = VarMin + rand(1,nVar).*(VarMax-VarMin);
    particle(i).Velocity = zeros(1,nVar);
    particle(i).Cost = hyperCost(particle(i).Position, Xtr, ytr, Xva, yva, weights);

    particle(i).Best.Position = particle(i).Position;
    particle(i).Best.Cost = particle(i).Cost;

    if particle(i).Best.Cost < BestSol.Cost
        BestSol = particle(i).Best;
    end
end

for it = 1:MaxIt
    for i = 1:nPop
        particle(i).Velocity = w * particle(i).Velocity ...
            + c1 * rand(1,nVar) .* (particle(i).Best.Position - particle(i).Position) ...
            + c2 * rand(1,nVar) .* (BestSol.Position - particle(i).Position);

        particle(i).Velocity = max(particle(i).Velocity, VelMin);
        particle(i).Velocity = min(particle(i).Velocity, VelMax);

        particle(i).Position = particle(i).Position + particle(i).Velocity;
        particle(i).Position = max(particle(i).Position, VarMin);
        particle(i).Position = min(particle(i).Position, VarMax);

        particle(i).Cost = hyperCost(particle(i).Position, Xtr, ytr, Xva, yva, weights);

        if particle(i).Cost < particle(i).Best.Cost
            particle(i).Best.Position = particle(i).Position;
            particle(i).Best.Cost = particle(i).Cost;

            if particle(i).Best.Cost < BestSol.Cost
                BestSol = particle(i).Best;
            end
        end
    end

    fprintf('PSO iter %d/%d | best hyper-cost = %.6f\n', it, MaxIt, BestSol.Cost);
    w = w * wdamp;
end

bestParams.C = 10^(BestSol.Position(1));
bestParams.epsilon = BestSol.Position(2);
bestParams.sigma = 10^(BestSol.Position(3));

end


function cost = hyperCost(pos, Xtr, ytr, Xva, yva, weights)

C = 10^(pos(1));
epsilon = pos(2);
sigma = 10^(pos(3));

try
    mdl = fitrsvm(Xtr, ytr, ...
        'KernelFunction', 'gaussian', ...
        'KernelScale', sigma, ...
        'BoxConstraint', C, ...
        'Epsilon', epsilon, ...
        'Standardize', true, ...
        'Weights', weights);

    yhat = predict(mdl, Xva);

    idxIC = (yva == 0);
    idxOC = (yva == 1);

    mseTerm = mean((yva - yhat).^2);

    if any(idxIC) && any(idxOC)
        meanIC = mean(yhat(idxIC));
        meanOC = mean(yhat(idxOC));
        meanSep = meanOC - meanIC;
        
        % 强制分离度至少0.3
        targetSep = 0.3;
        sepPenalty = 0;
        if meanSep < targetSep
            sepPenalty = (targetSep - meanSep) * 10;
        end
        
        rangePenalty = 0.05 * (std(yhat(idxIC)) + std(yhat(idxOC)));
    else
        meanSep = 0;
        sepPenalty = 0;
        rangePenalty = 0;
    end

    % 代价函数：主要优化分离度
    cost = 0.2 * mseTerm - 3.0 * meanSep + sepPenalty + rangePenalty;

    if ~isfinite(cost)
        cost = 1e9;
    end
catch ME
    cost = 1e9;
end

end