%% main_standard_pso_svr_ewma.m
% Standard-style PSO-SVR for EWMA-TBEA
% 修改：去掉lock循环，增加模拟次数

clear; close all; clc;
rng(2026,'twister');
addpath(pwd);

%% ================= Settings =================
% 数据生成设置
opts.fixed_seq_len = 100;      % 每个序列固定步数
opts.NumData_IC = 60;          % IC序列数
opts.NumData_OC = 60;          % OC序列数
opts.max_rl = 5000;            % 评估时的最大序列长度

opts.rep_cv = 800;
opts.rep_eval = 2000;          % 从800增加到2000，提高精度

% EWMA-TBEA parameters
opts.mu0 = 10;
opts.sigma0 = 1;
opts.sigma1 = 1;
opts.lambda = 1;
opts.UCLz = 0.1399;           % 使用搜索到的值
opts.EZ = 0.0146;
opts.tau = 0.8;
opts.NDivide = 2;                                                                                                                                            
    
% Training shifts
opts.rho1_IC = 1.00;
opts.rho2_IC = 1.00;

% Mixed OC training
opts.small_pairs = [
    1.01 1.00
    1.00 0.99
    1.01 0.99
    1.02 1.00
    1.00 0.98
    1.02 0.98
];

opts.medium_pairs = [
    1.03 1.00
    1.00 0.97
    1.03 0.97
    1.05 1.00
    1.00 0.95
    1.05 0.95
];
 
opts.large_pairs = [
    1.08 1.00
    1.00 0.92
    1.08 0.92
    1.10 1.00
    1.00 0.90
    1.10 0.90
];

opts.oc_mix_ratio = [0.60, 0.30, 0.10];

% Target ARL0
opts.target_ARL0_SVR = 200;

% PSO hyperparameter tuning settings
opts.pso.MaxIt = 20;
opts.pso.nPop  = 12;
opts.pso.w     = 0.7;
opts.pso.wdamp = 0.98;
opts.pso.c1    = 1.4;
opts.pso.c2    = 1.4;

% ARL grid
rho1_list = [1.00, 1.01, 1.02, 1.03, 1.04, 1.05, 1.06, 1.07, 1.08, 1.09, 1.10];
rho2_list = [1.00, 0.99, 0.98, 0.97, 0.96, 0.95, 0.94, 0.93, 0.92, 0.91, 0.90];

fprintf('========== Standard PSO-SVR-EWMA-TBEA ==========\n');
fprintf('fixed_seq_len = %d, NumData_IC = %d, NumData_OC = %d\n', ...
    opts.fixed_seq_len, opts.NumData_IC, opts.NumData_OC);
fprintf('rep_eval = %d (increased for better accuracy)\n', opts.rep_eval);

%% ================= Generate training data =================
[DATA, params] = genDataSVREWMATBEA(opts);
X = DATA(:,1:6);
y = DATA(:,7);

fprintf('Training rows = %d, input dim = %d\n', size(X,1), size(X,2));
fprintf('IC样本数: %d, OC样本数: %d\n', sum(y==0), sum(y==1));

%% ================= Tune SVR hyperparameters by PSO =================
bestParams = PSOTuneSVRHyperparams(X, y, opts);

fprintf('Best hyperparameters: C=%.4f | epsilon=%.4f | sigma=%.4f\n', ...
    bestParams.C, bestParams.epsilon, bestParams.sigma);

%% ================= Train standard SVR =================
% 计算样本权重
wIC = 1 / sum(y == 0);
wOC = 1 / sum(y == 1);
weights = zeros(size(y));
weights(y == 0) = wIC;
weights(y == 1) = wOC;
weights = weights / sum(weights) * length(weights);

svrModel = fitrsvm(X, y, ...
    'KernelFunction', 'gaussian', ...
    'KernelScale', bestParams.sigma, ...
    'BoxConstraint', bestParams.C, ...
    'Epsilon', bestParams.epsilon, ...
    'Standardize', true, ...
    'Weights', weights);

Yhat = predict(svrModel, X);

idxIC = (y == 0);
idxOC = (y == 1);

fprintf('IC mean = %.4f | OC mean = %.4f | gap = %.4f\n', ...
    mean(Yhat(idxIC)), mean(Yhat(idxOC)), mean(Yhat(idxOC)) - mean(Yhat(idxIC)));

%% ================= Recalibrate raw EWMA UCL =================
UCLz_new = SearchUCL_EWMA(params, opts);
params.UCLz = UCLz_new;
fprintf('Recalibrated EWMA UCLz = %.5f\n', UCLz_new);

% Lock EWMA UCL (保留，这个很快)
for k = 1:8
    arl0_e = EvalARL0_EWMA_IC(params, opts, 60101);
    fprintf('EWMA lock iter=%d | UCLz=%.5f | ARL0=%.2f\n', k, params.UCLz, arl0_e);

    if abs(arl0_e - opts.target_ARL0_SVR) <= 2
        break;
    end

    if arl0_e > opts.target_ARL0_SVR
        params.UCLz = params.UCLz * 0.998;
    else
        params.UCLz = params.UCLz * 1.002;
    end
end

fprintf('Locked EWMA UCLz = %.5f\n', params.UCLz);

%% ================= Search CV for SVR =================
% CV搜索（保留）
CV = TestCV_StdSVR_EWMA(svrModel, params, opts);
fprintf('Final CV from search = %.5f\n', CV);

% ================= 去掉Lock，直接使用搜索得到的CV =================
fprintf('\n=== Using CV from search (no lock) ===\n');
fprintf('CV = %.5f\n', CV);

% 验证一下ARL0（使用更精确的评估）
fprintf('Verifying ARL0 with rep_eval=%d...\n', opts.rep_eval);
arl0_final = EvalARL0_StdSVR_EWMA_IC(svrModel, params, CV, opts, 50101);
fprintf('Final ARL0 = %.2f (target = %d)\n', arl0_final, opts.target_ARL0_SVR);

if abs(arl0_final - opts.target_ARL0_SVR) > 10
    fprintf('Warning: ARL0 deviates by %.2f from target\n', abs(arl0_final - opts.target_ARL0_SVR));
    fprintf('Consider adjusting CV manually or increasing rep_eval further\n');
end

%% ================= Evaluate ARL =================
fprintf('\n=== Evaluating ARL for all shifts ===\n');
[ARL_SVR, ARL_EWMA] = CalculateARL_StdSVR_EWMA( ...
    svrModel, params, CV, rho1_list, rho2_list, opts);

disp('ARL_SVR =');
disp(ARL_SVR);
disp('ARL_EWMA =');
disp(ARL_EWMA);

save('Standard_PSO_SVR_EWMA_TBEA.mat', ...
    'svrModel', 'params', 'opts', 'bestParams', 'CV', 'ARL_SVR', 'ARL_EWMA');

fprintf('========== Finished ==========\n');