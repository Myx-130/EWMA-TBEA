function Output = CountStatinDivide(CountStat, UCL, NumData, NDivide)
Divides = zeros(1, NDivide);
CountDivides = zeros(1, NDivide+1);
Output = zeros(NumData, NDivide+2);

for j = 1:NDivide
    Divides(j) = (UCL/NDivide) + ((j-1)*(UCL/NDivide));
end

for i = 1:NumData
    for j = 1:NDivide+1
        if j == NDivide+1
            CountDivides(j) = CountDivides(j) + 1;
            Output(i,1:NDivide+1) = CountDivides ./ i;
            break;
        end

        if CountStat(i) < Divides(j)
            CountDivides(j) = CountDivides(j) + 1;
            Output(i,1:NDivide+1) = CountDivides ./ i;
            break;
        end
    end
end

Output(:, end) = CountStat(:);
end