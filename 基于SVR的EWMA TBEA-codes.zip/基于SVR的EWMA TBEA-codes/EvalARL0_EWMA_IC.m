function arl0 = EvalARL0_EWMA_IC(params, opts, seed)

mu0 = params.mu0;
sigma0 = params.sigma0;
sigma1 = params.sigma1;
lambda = params.lambda;
UCLz = params.UCLz;
EZ = params.EZ;
tau = params.tau;

rho1 = 1.00;
rho2 = 1.00;

muX1 = rho1 * mu0;
muT1 = rho2 * mu0;

aX1 = (muX1 / sigma0)^2;
bX1 = muX1 / aX1;
aT1 = (muT1 / sigma1)^2;
bT1 = muT1 / aT1;

theta = francktheta(tau);

rng(seed, 'twister');
RL = zeros(opts.rep_eval, 1);

for i = 1:opts.rep_eval
    Z = EZ;

    for j = 1:opts.max_rl
        [u, v] = frank_copula_samples(theta, 1);

        X1 = gaminv(u, aX1, bX1) / mu0;
        T1 = gaminv(v, aT1, bT1) / mu0;

        x = X1 - T1;
        Z = lambda * x + (1 - lambda) * Z;
        Z = max(EZ, Z);

        if Z > UCLz
            RL(i) = j;
            break;
        end

        if j == opts.max_rl
            RL(i) = opts.max_rl;
        end
    end
end

arl0 = mean(RL);

end


function [u, v] = frank_copula_samples(theta, n)
u = rand(n, 1);
w = rand(n, 1);
v = -(1/theta) .* log(1 + (w .* (1 - exp(-theta))) ./ ...
    (w .* (exp(-theta .* u) - 1) - exp(-theta .* u)));
end
