function [DATA, params] = genDataSVREWMATBEA(opts)
% DATA columns: [X1, T1, Z, prop1, prop2, prop3, Target]
% 每个序列固定长度 FIXED_LEN，确保IC和OC样本数平衡

FIXED_LEN = opts.fixed_seq_len;  % 每个序列固定步数

% IC 数据
fprintf('生成IC数据...\n');
ANNPM_IC = genSamplesFixedLen(opts.NumData_IC, opts.rho1_IC, opts.rho2_IC, 0, opts, FIXED_LEN);

% OC 数据（混合多种偏移）
fprintf('生成OC数据...\n');
small_pairs = opts.small_pairs;
medium_pairs = opts.medium_pairs;
large_pairs = opts.large_pairs;
mix_ratio = opts.oc_mix_ratio(:)';

nSmall  = round(opts.NumData_OC * mix_ratio(1));
nMedium = round(opts.NumData_OC * mix_ratio(2));
nLarge  = opts.NumData_OC - nSmall - nMedium;

ANNPM_OC = [];
ANNPM_OC = [ANNPM_OC; genGroupSamplesFixedLen(nSmall,  small_pairs,  opts, 1, FIXED_LEN)];
ANNPM_OC = [ANNPM_OC; genGroupSamplesFixedLen(nMedium, medium_pairs, opts, 1, FIXED_LEN)];
ANNPM_OC = [ANNPM_OC; genGroupSamplesFixedLen(nLarge,  large_pairs,  opts, 1, FIXED_LEN)];

DATA = [ANNPM_IC; ANNPM_OC];

fprintf('数据生成完成: IC样本数=%d, OC样本数=%d, 总计=%d\n', ...
    size(ANNPM_IC,1), size(ANNPM_OC,1), size(DATA,1));

params.mu0 = opts.mu0;
params.sigma0 = opts.sigma0;
params.sigma1 = opts.sigma1;
params.lambda = opts.lambda;
params.UCLz = opts.UCLz;
params.EZ = opts.EZ;
params.tau = opts.tau;
params.NDivide = opts.NDivide;

end


function DATA = genGroupSamplesFixedLen(totalNum, pairSet, opts, Target, FIXED_LEN)

nPairs = size(pairSet, 1);
baseNum = floor(totalNum / nPairs);
remNum  = totalNum - baseNum * nPairs;

DATA = [];
for k = 1:nPairs
    nk = baseNum + (k <= remNum);
    if nk <= 0
        continue;
    end
    rho1 = pairSet(k,1);
    rho2 = pairSet(k,2);
    data_k = genSamplesFixedLen(nk, rho1, rho2, Target, opts, FIXED_LEN);
    DATA = [DATA; data_k];
end

end


function DATA = genSamplesFixedLen(NumSeq, rho1, rho2, Target, opts, FIXED_LEN)
% 生成固定长度的序列，不提前停止

lambda = opts.lambda;
UCLz = opts.UCLz;
mu0 = opts.mu0;
sigma0 = opts.sigma0;
sigma1 = opts.sigma1;
EZ = opts.EZ;
NDivide = opts.NDivide;
tau = opts.tau;

muX1 = rho1 * mu0;
muT1 = rho2 * mu0;
aX1 = (muX1 / sigma0)^2;
bX1 = muX1 / aX1;
aT1 = (muT1 / sigma1)^2;
bT1 = muT1 / aT1;

theta = francktheta(tau);

DATA = [];

for seq = 1:NumSeq
    Z = EZ;
    tempDATA = zeros(FIXED_LEN, 4+NDivide+1+1);  % 预分配
    
    for j = 1:FIXED_LEN
        [u, v] = frank_copula_samples(theta, 1);
        X1 = gaminv(u, aX1, bX1) / mu0;
        T1 = gaminv(v, aT1, bT1) / mu0;
        
        x = X1 - T1;
        Z = lambda * x + (1 - lambda) * Z;
        Z = max(EZ, Z);
        
        tempDATA(j,1:3) = [X1, T1, Z];
        StatEWMA = CountStatinDivide_EWMA(tempDATA(1:j,3), UCLz, EZ, j, NDivide);
        currProps = StatEWMA(end,1:(NDivide+1));
        tempDATA(j,4:(3+NDivide+1)) = currProps;
        tempDATA(j,4+NDivide+1) = Target;
    end
    
    DATA = [DATA; tempDATA];
end

end


function [u, v] = frank_copula_samples(theta, n)
u = rand(n, 1);
w = rand(n, 1);
v = -(1/theta) .* log(1 + (w .* (1 - exp(-theta))) ./ ...
    (w .* (exp(-theta .* u) - 1) - exp(-theta .* u)));
end