function UCLz_new = SearchUCL_EWMA(params, opts)

mu0 = params.mu0;
sigma0 = params.sigma0;
sigma1 = params.sigma1;
lambda = params.lambda;
EZ = params.EZ;
tau = params.tau;

target_ARL = opts.target_ARL0_SVR;

% 关键：这里也和最终评估口径一致
rep_search = opts.rep_eval;
max_rl_search = opts.max_rl;

rho1 = 1.00;
rho2 = 1.00;

muX1 = rho1 * mu0;
muT1 = rho2 * mu0;

aX1 = (muX1 / sigma0)^2;
bX1 = muX1 / aX1;
aT1 = (muT1 / sigma1)^2;
bT1 = muT1 / aT1;

theta = francktheta(tau);

ucl_low = 0.02;
ucl_high = 1.00;

arl_high = evalARL_EWMA(ucl_high, rep_search, max_rl_search, ...
    aX1, bX1, aT1, bT1, mu0, EZ, lambda, theta, 2026032301);

expand_iter = 0;
while arl_high < target_ARL && expand_iter < 10
    ucl_high = ucl_high * 1.5;
    arl_high = evalARL_EWMA(ucl_high, rep_search, max_rl_search, ...
        aX1, bX1, aT1, bT1, mu0, EZ, lambda, theta, 2026032301);
    expand_iter = expand_iter + 1;
end

bestUCL = ucl_high;
bestGap = inf;

for iter = 1:20
    ucl_try = (ucl_low + ucl_high) / 2;

    ARL = evalARL_EWMA(ucl_try, rep_search, max_rl_search, ...
        aX1, bX1, aT1, bT1, mu0, EZ, lambda, theta, 2026032301);

    fprintf('EWMA UCL iter=%d | UCLz=%.5f | ARL0=%.2f\n', iter, ucl_try, ARL);

    currGap = abs(ARL - target_ARL);
    if currGap < bestGap
        bestGap = currGap;
        bestUCL = ucl_try;
    end

    % 提前停止：误差在 ±1 以内就接受
    if currGap <= 1
        UCLz_new = ucl_try;
        return;
    end

    if ARL > target_ARL
        ucl_high = ucl_try;
    else
        ucl_low = ucl_try;
    end
end

UCLz_new = bestUCL;

end


% ==================== 嵌套函数定义在文件末尾 ====================

function ARL = evalARL_EWMA(UCLz, rep, max_rl, aX1, bX1, aT1, bT1, mu0, EZ, lambda, theta, seed)
rng(seed, 'twister');
RL = zeros(rep, 1);

for i = 1:rep
    Z = EZ;
    for j = 1:max_rl
        [u, v] = frank_copula_samples(theta, 1);

        X1 = gaminv(u, aX1, bX1) / mu0;
        T1 = gaminv(v, aT1, bT1) / mu0;

        x = X1 - T1;
        Z = lambda * x + (1 - lambda) * Z;
        Z = max(EZ, Z);

        if Z > UCLz
            RL(i) = j;
            break;
        end

        if j == max_rl
            RL(i) = max_rl;
        end
    end
end

ARL = mean(RL);
end


function [u, v] = frank_copula_samples(theta, n)
u = rand(n, 1);
w = rand(n, 1);
v = -(1/theta) .* log(1 + (w .* (1 - exp(-theta))) ./ ...
    (w .* (exp(-theta .* u) - 1) - exp(-theta .* u)));
end