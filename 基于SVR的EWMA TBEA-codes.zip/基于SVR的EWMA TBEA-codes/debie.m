function d = debie(theta)
    function y = debie_(t)
        y = t ./ (exp(t) - 1);
    end
    d = integral(@debie_, 0, theta) / theta;
end
