%% 批量将 Z1 改为 Z3
files = {
    'genDataSVREWMATBEA.m',
    'TestCV_StdSVR_EWMA.m',
    'EvalARL0_StdSVR_EWMA_IC.m',
    'CalculateARL_StdSVR_EWMA.m',
    'SearchUCL_EWMA.m',
    'demo_predict_SVR_Final.m',
    'EvalARL0_EWMA_IC.m'
};

for i = 1:length(files)
    filename = files{i};
    if exist(filename, 'file')
        content = fileread(filename);
        % 将差值改为和的形式
        content = strrep(content, 'x = X1 - T1;', 'x = X1 + 1./T1;');
        % 注意：1/T1 需要用 1./T1 确保是逐元素除法
        fid = fopen(filename, 'w');
        fprintf(fid, '%s', content);
        fclose(fid);
        fprintf('已修改: %s\n', filename);
    else
        fprintf('文件不存在: %s\n', filename);
    end
end

fprintf('\n完成！请手动修改以下内容:\n');
fprintf('1. opts.EZ = 2.0 (需要精确计算)\n');
fprintf('2. SearchUCL_EWMA.m 中的 ucl_low = 1.0, ucl_high = 5.0\n');
fprintf('3. TestCV_StdSVR_EWMA.m 中的 cv_low = 1.0, cv_high = 3.0\n');