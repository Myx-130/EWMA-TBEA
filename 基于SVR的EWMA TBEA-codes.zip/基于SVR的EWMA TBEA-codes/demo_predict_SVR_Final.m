%% demo_predict_SVR.m
% 从原始 X、T 数据计算每个样本的 SVR 输出值
% 直接运行即可，所有逻辑在一个文件内

% ========== 1. 加载训练好的模型和参数 ==========
load('Standard_PSO_SVR_EWMA_TBEA_Final.mat');

% ========== 2. 你的原始数据（14 个样本）==========
T_raw = [63; 69; 47; 69; 91; 45; 70; 54; 23; 44; 56; 68; 26; 33];
X_raw = [5080; 5350; 3770; 4590; 5940; 5420; 4580; 5430; 5740; 6110; 7340; 8160; 4800; 6570];

n = length(X_raw);
fprintf('共有 %d 个样本\n', n);

% ========== 3. 计算 SVR 值（函数逻辑内嵌）==========
muX0 = params.muX0;
muT0 = params.muT0;
EZ = 0.0826;
lambda = params.lambda;
UCLz = params.UCLz;
NDivide = params.NDivide;

% 标准化
X1 = X_raw / muX0;
T1 = T_raw / muT0;

% 递推计算 EWMA 统计量 Z
Z = EZ;
Z_seq = zeros(n, 1);
for j = 1:n
    x = X1(j) - T1(j);
    Z = lambda * x + (1 - lambda) * Z;
    Z = max(EZ, Z);
    Z_seq(j) = Z;
end

% 计算分区比例 prop
CountStat = Z_seq;
Output = CountStatinDivide_EWMA(CountStat, UCLz, EZ, n, NDivide);
prop = Output(:, 1:NDivide+1);

% 组合 6 维特征
features = [X1, T1, Z_seq, prop];

% SVR 预测
svrVals = predict(svrModel, features);

% ========== 4. 输出结果 ==========
fprintf('\n各样本的 SVR 预测值:\n');
for i = 1:n
    fprintf('样本 %2d: X=%6.0f, T=%3d  |  SVR=%.4f\n', i, X_raw(i), T_raw(i), svrVals(i));
end

% 报警判断
fprintf('\n当前 CV = %.5f, UCL = %.5f\n', CV, UCLz);

svr_alarms = svrVals > CV;
ewma_alarms = Z_seq > UCLz;

fprintf('报警样本数: SVR=%d / %d, EWMA=%d / %d\n', sum(svr_alarms), n, sum(ewma_alarms), n);

fprintf('\n各样本详细结果:\n');
for i = 1:n
    svr_flag = '正常';
    ewma_flag = '正常';
    if svr_alarms(i), svr_flag = '报警'; end
    if ewma_alarms(i), ewma_flag = '报警'; end
    fprintf('样本 %2d: X=%6.0f, T=%3d  |  SVR=%.4f(%s)  |  EWMA_Z=%.5f(%s)\n', ...
        i, X_raw(i), T_raw(i), svrVals(i), svr_flag, Z_seq(i), ewma_flag);
end

if any(svr_alarms)
    fprintf('\nSVR 报警样本编号: '); fprintf('%d ', find(svr_alarms)); fprintf('\n');
end
if any(ewma_alarms)
    fprintf('EWMA 报警样本编号: '); fprintf('%d ', find(ewma_alarms)); fprintf('\n');
end

% ========== 5. 保存结果到 CSV ==========
result_table = table((1:n)', X_raw, T_raw, svrVals, svr_alarms, Z_seq, ewma_alarms, ...
    'VariableNames', {'编号','X_raw','T_raw','SVR值','SVR报警','EWMA_Z','EWMA报警'});
writetable(result_table, 'SVR预测结果.csv');
fprintf('\n结果已保存到 SVR预测结果.csv\n');