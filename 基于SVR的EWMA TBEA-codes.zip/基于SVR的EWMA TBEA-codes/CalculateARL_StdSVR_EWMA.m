function [ARL_SVR, ARL_EWMA] = CalculateARL_StdSVR_EWMA(svrModel, params, CV, rho1_list, rho2_list, opts)

mu0 = params.mu0;
sigma0 = params.sigma0;
sigma1 = params.sigma1;
lambda = params.lambda;
UCLz = params.UCLz;
EZ = params.EZ;
tau = params.tau;
NDivide = params.NDivide;

n1 = length(rho1_list);
n2 = length(rho2_list);

ARL_SVR = zeros(n1, n2);
ARL_EWMA = zeros(n1, n2);

theta = francktheta(tau);

for r1 = 1:n1
    for r2 = 1:n2

        rho1 = rho1_list(r1);
        rho2 = rho2_list(r2);

        muX1 = rho1 * mu0;
        muT1 = rho2 * mu0;

        aX1 = (muX1 / sigma0)^2;
        bX1 = muX1 / aX1;
        aT1 = (muT1 / sigma1)^2;
        bT1 = muT1 / aT1;

        ARL_SVR(r1, r2) = evalARL_SVR_only( ...
            svrModel, CV, UCLz, EZ, lambda, theta, NDivide, ...
            aX1, bX1, aT1, bT1, mu0, opts.rep_eval, opts.max_rl, ...
            50000 + 100*r1 + r2);

        ARL_EWMA(r1, r2) = evalARL_EWMA_only( ...
            UCLz, EZ, lambda, theta, ...
            aX1, bX1, aT1, bT1, mu0, opts.rep_eval, opts.max_rl, ...
            60000 + 100*r1 + r2);

        fprintf('rho1=%.2f, rho2=%.2f | SVR=%.2f | EWMA=%.2f\n', ...
            rho1, rho2, ARL_SVR(r1, r2), ARL_EWMA(r1, r2));
    end
end

end


function ARL = evalARL_SVR_only(svrModel, CV, UCLz, EZ, lambda, theta, NDivide, ...
    aX1, bX1, aT1, bT1, mu0, rep, max_rl, seed)

rng(seed, 'twister');
RL = zeros(rep, 1);

for i = 1:rep
    Z = EZ;
    j = 1;
    Z_history = zeros(max_rl, 1);

    while true
        [u, v] = frank_copula_samples(theta, 1);

        X1 = gaminv(u, aX1, bX1) / mu0;
        T1 = gaminv(v, aT1, bT1) / mu0;

        x = X1 - T1;
        Z = lambda * x + (1 - lambda) * Z;
        Z = max(EZ, Z);
        Z_history(j) = Z;

        StatEWMA = CountStatinDivide_EWMA(Z_history(1:j), UCLz, EZ, j, NDivide);
        currProps = StatEWMA(end, 1:(NDivide+1));

        inputSVR = [X1, T1, Z, currProps];
        Yhat = predict(svrModel, inputSVR);

        if Yhat > CV
            RL(i) = j;
            break;
        end

        j = j + 1;

        if j > max_rl
            RL(i) = max_rl;
            break;
        end
    end
end

ARL = mean(RL);

end


function ARL = evalARL_EWMA_only(UCLz, EZ, lambda, theta, ...
    aX1, bX1, aT1, bT1, mu0, rep, max_rl, seed)

rng(seed, 'twister');
RL = zeros(rep, 1);

for i = 1:rep
    Z = EZ;

    for j = 1:max_rl
        [u, v] = frank_copula_samples(theta, 1);

        X1 = gaminv(u, aX1, bX1) / mu0;
        T1 = gaminv(v, aT1, bT1) / mu0;

        x = X1 - T1;
        Z = lambda * x + (1 - lambda) * Z;
        Z = max(EZ, Z);

        if Z > UCLz
            RL(i) = j;
            break;
        end

        if j == max_rl
            RL(i) = max_rl;
        end
    end
end

ARL = mean(RL);

end


function [u, v] = frank_copula_samples(theta, n)
u = rand(n, 1);
w = rand(n, 1);
v = -(1/theta) .* log(1 + (w .* (1 - exp(-theta))) ./ ...
    (w .* (exp(-theta .* u) - 1) - exp(-theta .* u)));
end