function theta = francktheta(tau)
    function z = francktheta_(theta, tau)
        z = tau - 1 - 4 * (debie(theta) - 1) / theta;
    end
    theta = fsolve(@(theta) francktheta_(theta, tau), 1);
end
