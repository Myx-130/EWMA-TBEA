function Output = CountStatinDivide_EWMA(CountStat, UCL, EZ, NumData, NDivide)
% 专门用于EWMA的分区统计，分区范围从EZ到UCL
% CountStat: 统计量序列
% UCL: 控制上限
% EZ: 统计量下界（EWMA的截断值）
% NumData: 当前数据点数
% NDivide: 分区数量

Divides = zeros(1, NDivide);
CountDivides = zeros(1, NDivide+1);
Output = zeros(NumData, NDivide+2);

range = UCL - EZ;
if range <= 0
    warning('UCL <= EZ，分区可能无效');
    range = 0.001;
end

for j = 1:NDivide
    Divides(j) = EZ + (j * range / NDivide);
end

for i = 1:NumData
    for j = 1:NDivide+1
        if j == NDivide+1
            CountDivides(j) = CountDivides(j) + 1;
            Output(i,1:NDivide+1) = CountDivides ./ i;
            break;
        end
        
        if CountStat(i) < Divides(j)
            CountDivides(j) = CountDivides(j) + 1;
            Output(i,1:NDivide+1) = CountDivides ./ i;
            break;
        end
    end
end

Output(:, end) = CountStat(:);
end