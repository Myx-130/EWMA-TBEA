function CV = TestCV_StdSVR_EWMA(svrModel, params, opts)

mu0 = params.mu0;
sigma0 = params.sigma0;
sigma1 = params.sigma1;
lambda = params.lambda;
UCLz = params.UCLz;
EZ = params.EZ;
tau = params.tau;
NDivide = params.NDivide;

theta = francktheta(tau);

target_ARL = opts.target_ARL0_SVR;

rep_search = opts.rep_eval;
max_rl_search = opts.max_rl;

rho1 = 1.00;
rho2 = 1.00;

muX1 = rho1 * mu0;
muT1 = rho2 * mu0;

aX1 = (muX1 / sigma0)^2;
bX1 = muX1 / aX1;
aT1 = (muT1 / sigma1)^2;
bT1 = muT1 / aT1;

% CV搜索范围（根据模型输出调整）
cv_low = 0.1;
cv_high = 1.5;      % 上限提高到1.5

bestCV = cv_high;
bestGap = inf;

seed_list = [2026032311, 2026032312, 2026032313];

for iter = 1:25      % 增加迭代次数
    cv_try = (cv_low + cv_high) / 2;

    ARL_now = evalARL_SVR_multiSeed(cv_try, svrModel, rep_search, max_rl_search, ...
        aX1, bX1, aT1, bT1, mu0, EZ, lambda, UCLz, theta, NDivide, seed_list);

    fprintf('CV iter=%d | CV=%.5f | ARL0=%.2f\n', iter, cv_try, ARL_now);

    currGap = abs(ARL_now - target_ARL);
    if currGap < bestGap
        bestGap = currGap;
        bestCV = cv_try;
    end

    % 提前停止
    if currGap <= 2
        CV = cv_try;
        return;
    end

    if ARL_now > target_ARL
        cv_high = cv_try;
    else
        cv_low = cv_try;
    end
    
    % 移除过早终止的条件！或者改为更大的上限
    % 只有当cv_low超过合理上限（如1.5）时才警告
    if cv_low > 1.5
        fprintf('警告：CV搜索超出范围，使用最佳CV=%.5f (ARL0=%.2f)\n', bestCV, ARL_now);
        break;
    end
end

CV = bestCV;

end


function ARL = evalARL_SVR_multiSeed(CV, svrModel, rep, max_rl, ...
    aX1, bX1, aT1, bT1, mu0, EZ, lambda, UCLz, theta, NDivide, seed_list)

arl_vec = zeros(numel(seed_list), 1);

for s = 1:numel(seed_list)
    arl_vec(s) = evalARL_SVR_oneSeed(CV, svrModel, rep, max_rl, ...
        aX1, bX1, aT1, bT1, mu0, EZ, lambda, UCLz, theta, NDivide, seed_list(s));
end

ARL = mean(arl_vec);

end


function ARL = evalARL_SVR_oneSeed(CV, svrModel, rep, max_rl, ...
    aX1, bX1, aT1, bT1, mu0, EZ, lambda, UCLz, theta, NDivide, seed)

rng(seed, 'twister');
RL = zeros(rep, 1);

for i = 1:rep
    Z = EZ;
    j = 1;
    Z_history = zeros(max_rl, 1);

    while true
        [u, v] = frank_copula_samples(theta, 1);

        X1 = gaminv(u, aX1, bX1) / mu0;
        T1 = gaminv(v, aT1, bT1) / mu0;

        x = X1 - T1;
        Z = lambda * x + (1 - lambda) * Z;
        Z = max(EZ, Z);
        Z_history(j) = Z;

        StatEWMA = CountStatinDivide_EWMA(Z_history(1:j), UCLz, EZ, j, NDivide);
        currProps = StatEWMA(end, 1:(NDivide+1));

        inputSVR = [X1, T1, Z, currProps];
        Yhat = predict(svrModel, inputSVR);

        if Yhat > CV
            RL(i) = j;
            break;
        end

        j = j + 1;

        if j > max_rl
            RL(i) = max_rl;
            break;
        end
    end
end

ARL = mean(RL);

end


function [u, v] = frank_copula_samples(theta, n)
u = rand(n, 1);
w = rand(n, 1);
v = -(1/theta) .* log(1 + (w .* (1 - exp(-theta))) ./ ...
    (w .* (exp(-theta .* u) - 1) - exp(-theta .* u)));
end