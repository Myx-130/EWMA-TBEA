% 批量将 Z1 改为 Z2
files = {
    'genDataSVREWMATBEA.m',
    'TestCV_StdSVR_EWMA.m',
    'EvalARL0_StdSVR_EWMA_IC.m',
    'CalculateARL_StdSVR_EWMA.m',
    'SearchUCL_EWMA.m',
    'demo_predict_SVR_Final.m',
    'EvalARL0_EWMA_IC.m'
};

for i = 1:length(files)
    filename = files{i};
    if exist(filename, 'file')
        % 读取文件
        content = fileread(filename);
        % 替换
        content = strrep(content, 'x = X1 - T1;', 'x = X1 ./ T1;');
        % 写回
        fid = fopen(filename, 'w');
        fprintf(fid, '%s', content);
        fclose(fid);
        fprintf('已修改: %s\n', filename);
    else
        fprintf('文件不存在: %s\n', filename);
    end
end

fprintf('\n完成！请记得修改 opts.EZ = 1.0\n');