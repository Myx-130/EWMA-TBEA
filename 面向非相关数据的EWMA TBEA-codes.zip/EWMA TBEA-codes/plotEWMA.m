clear; clc;
data0 = load('EMMA.txt');
UCL = 95.6844;

% 增加图表的尺寸
figure('Position', [100 100 1200 700]); % 宽度1000, 高度400

x = 1:length(data0); % 使用所有数据点的索引
plot(x, data0, 'o-', 'MarkerSize', 6, 'LineWidth', 1.2); % 使用较小的点和细线

hold on;
plot([1, length(data0)], [UCL, UCL], 'r--'); % 绘制UCL线，使用红色虚线

% 调整文本标签的位置和格式（使用\mathrm{}强制正体，保留LaTeX下标）
text(42, UCL - 3.5, '$\mathrm{UCL}_3 = 95.6844$', ...
    'Interpreter', 'latex', 'FontSize', 12, 'HorizontalAlignment', 'center', ...
    'FontAngle', 'normal'); % 显式设置非斜体

% 设置坐标轴属性
set(gca, 'xlim', [1 max(x)]); % 自动调整x轴的范围
set(gca, 'xtick', 1:5:max(x)); % 每隔10个点设置一个刻度
set(gca, 'ylim', [-5 100]);
set(gca, 'ytick', -5:5:100);

% 设置坐标轴标签和标题
xlabel('$t$', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('$E_t^+$', 'Interpreter', 'latex', 'FontSize', 12);

% 设置坐标轴框和刻度方向
set(gca, 'box', 'off');
ax = gca;
ax.XAxis.TickDirection = 'out';
ax.YAxis.TickDirection = 'out';

hold off;