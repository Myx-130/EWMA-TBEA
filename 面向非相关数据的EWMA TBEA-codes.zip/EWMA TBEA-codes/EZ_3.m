integrand = @(z)(z.*pdfZ(z, 1, 10, 10, 1, 1, 10, 10, 1));
Ez = integral(integrand, eps, 10);

z=[-10:0.01:10];
y = pdfZ(z, 1, 10, 10, 1, 1, 10, 10, 1);
plot(z,y);