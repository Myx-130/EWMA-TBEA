function EARL = EARLewmatbea(lam, UCL, disX, muX0, sdX0, disT, muT0, sdT0)
    % 定义 x 和 y 向量
    x = 0.1 * (0:2) + 1; % [1, 1.1, 1.2, 1.3, 1.4, 1.5]
    y = 1 - 0.05 * (0:2); % [1, 0.95, 0.9, 0.85, 0.8, 0.75]

    % 使用 meshgrid 生成网格矩阵
    [X, Y] = meshgrid(x, y);

    % 计算 ARL1 矩阵
    ARL1 = arrayfun(@(x_val, y_val) rluewmatbea(lam, UCL, disX, muX0, sdX0, disT, muT0, sdT0, x_val, y_val), X, Y);

    EARL=mean(ARL1,"all")
end