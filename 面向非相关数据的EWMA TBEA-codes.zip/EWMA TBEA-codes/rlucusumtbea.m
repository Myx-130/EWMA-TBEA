%%Traditional Sided-Sensitive CUSUM-ZERO-STATE
%%S(i)=max(0,S(i-1)+Z(i)-z0-K), S(0)=0, UCL=H*z0;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function ARL=rlucusumtbea(K,UCL,disX,muX0,sdX0,disT,muT0,sdT0,rho1,rho2)
r=100;
z0=0;
x0=-0.047;
pr=2*r+1;
dr=(UCL-z0)/(2*pr);
hr=linspace(z0+dr,UCL-dr,pr);
hr=[z0 hr];
Hj=ones(pr+1,1)*hr;
Hi=Hj';
Q1=(x0+Hj-Hi+dr+K);
Q2=(x0+Hj-Hi-dr+K);
Q=cdfZ_Z1(Q1,disX,muX0,sdX0,disT,muT0,sdT0,rho1,rho2)-cdfZ_Z1(Q2,disX,muX0,sdX0,disT,muT0,sdT0,rho1,rho2);
Q(:,1)=cdfZ_Z1(x0-Hi(:,1)+K,disX,muX0,sdX0,disT,muT0,sdT0,rho1,rho2);% 1the column is changed. 
q=zeros(pr+1,1);
q(1)=1;
W=inv(eye(pr+1,pr+1)-Q);
ARL=sum(q'*W);