%%%%%%蒙特卡洛仿真，EWMA 已知参数
function [ARL,MRL,SDRL]=rlUewmaExpS_Z1(lam,UCLe,rho1,rho2,muX0,muT0)
if (lam<=0)||(lam>1)
  error('argument ''lam'' must be in (0,1]')
end

mu0=10;
sigma0=1;
sigma1=5;
a0=100;
b0=0.1;
a1=10;
b1=1;
muX1=rho1*muX0;
muT1=rho2*muT0;
aX1=(muX1/sigma0)^2;
bX1=(muX1/aX1);
aT1=(muT1/sigma1)^2;
bT1=(muT1/aT1);

rep=10^5;
RL=zeros(rep,1);
Z0=0.1992;
for i=1:rep
  j=1;
  X1=gamrnd(aX1,bX1)/mu0;
  T1=gamrnd(aT1,bT1)/mu0;
  X=X1-T1;
  Z=lam*X+(1-lam)*Z0;
  Z=max(Z0,Z);
  while true
    if Z>UCLe
      RL(i)=j;
      break
    end
    X1=gamrnd(aX1,bX1)/mu0;
    T1=gamrnd(aT1,bT1)/mu0;
    X=X1-T1;
    Z=lam*X+(1-lam)*Z;
    Z=max(Z0,Z);
    j=j+1;
  end
end
ARL=mean(RL);
MRL=median(RL);
SDRL=std(RL);