function [] = EARLForCombinations()
    % 预定义的固定参数值
    disX = 1; % 填入你的值
    muX0 = 10; % 填入你的值
    sdX0 = 1; % 填入你的值
    disT = 1; % 填入你的值
    muT0 = 10; % 填入你的值
    sdT0 = 1; % 填入你的值

    % 定义 (lam, UCL) 的组合
    combinations = [ 
    1, 0.3659
    ];

    % 预分配结果数组
    numCombinations = size(combinations, 1);
    EARLs = zeros(numCombinations, 1);

    % 打开文件以进行写入
    fileID = fopen('EARL_results.txt', 'w');

    % 循环遍历每个 (lam, UCL) 组合
    for i = 1:numCombinations
        lam = combinations(i, 1);
        UCL = combinations(i, 2);
        EARLs(i) = EARLewmatbea(lam, UCL, disX, muX0, sdX0, disT, muT0, sdT0);
        
        % 输出到命令窗口
        fprintf('For (lam, UCL) = (%.2f, %.4f): EARL = %.4f\n', lam, UCL, EARLs(i));
        
        % 写入文件
        fprintf(fileID, 'For (lam, UCL) = (%.2f, %.4f): EARL = %.4f\n', lam, UCL, EARLs(i));
    end

    % 关闭文件
    fclose(fileID);
end

% EARL 计算函数
function EARL = EARLewmatbea(lam, UCL, disX, muX0, sdX0, disT, muT0, sdT0)
    % 定义 x 和 y 向量
    x = 0.2 * (0:10) + 1; 
    y = 0.9 - 0.05 * (0:10); 

    % 使用 meshgrid 生成网格矩阵
    [X, Y] = meshgrid(x, y);

    % 计算 ARL1 矩阵
    ARL1 = arrayfun(@(x_val, y_val) rluewmatbea(lam, UCL, disX, muX0, sdX0, disT, muT0, sdT0, x_val, y_val), X, Y);

    % 计算 EARL
    EARL = mean(ARL1(:));
end