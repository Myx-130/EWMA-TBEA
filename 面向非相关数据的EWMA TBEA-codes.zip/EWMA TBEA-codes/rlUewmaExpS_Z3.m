function [ARL,MRL,SDRL]=rlUewmaExpS_Z3(lam,UCLe,rho1,rho2)
if (lam<=0)||(lam>1)
  error('argument ''lam'' must be in (0,1]')
end

muT0=14.7600;
muX0=3.9840;
sigma0=1.9752;
sigma1=17.9404;
a0=0.8860;
b0=16.6591;
muX1=rho1*muX0;
muT1=rho2*muT0;
aX1=(muX1/sigma0)^2;
bX1=(muX1/aX1);
aT1=(muT1/sigma1)^2;
bT1=(muT1/aT1);

rep=10^5;
RL=zeros(rep,1);
Z0=2.4593;
for i=1:rep
  j=1;
  X1=gamrnd(aX1,bX1)/muX0;
  T1=gamrnd(aT1,bT1)/muT0;
  X=X1+1/T1;
  Z=lam*X+(1-lam)*Z0;
  Z=max(Z0,Z);
  while true
    if Z>UCLe
      RL(i)=j;
      break
    end
    X1=gamrnd(aX1,bX1)/muX0;
    T1=gamrnd(aT1,bT1)/muT0;
    X=X1+1/T1;
    Z=lam*X+(1-lam)*Z;
    Z=max(Z0,Z);
    j=j+1;
  end
end
ARL=mean(RL);
MRL=median(RL);
SDRL=std(RL);