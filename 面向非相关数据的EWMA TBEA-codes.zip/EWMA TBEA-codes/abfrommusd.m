function [a, b] = abfrommusd(dis, mu, sd)
    % Check the number of input arguments
    % 1为Gamma分布
    % 2为Lognormal分布
    % 3为Normal分布
    % 4为Weibull分布
    narginchk(3, 3);
    assert(sd > 0, 'Argument ''sd'' must be > 0');

    switch dis
        case 1
            a = (mu / sd)^2;
            b = mu / a;
        case 2
            b = 1 / sqrt(log(1 + (sd / mu)^2));
            a = -b * log(mu / sqrt(1 + (sd / mu)^2));
        case 3
            a = mu;
            b = sd;
        case 4
            options = optimset('Display', 'off');
            a = fsolve(@(a) abfrommusdW(a, mu, sd), 2, options);
            b = mu / gamma(1 / a + 1);
        otherwise, error('Argument ''dis'' must be ''G'', ''L'', ''N'', or ''W''');
    end
end

function z = abfrommusdW(a, mu, sd)
    if a <= 0, z = 1e4;
    else, z = mu^2 * (gamma(2 / a + 1) / gamma(1 / a + 1)^2 - 1) - sd^2;
    end
end