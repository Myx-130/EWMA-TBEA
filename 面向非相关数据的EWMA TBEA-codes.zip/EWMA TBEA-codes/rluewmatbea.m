%Traditional Sided-Sensitive-EWMA-ZERO-STATE
%%Z(k)=MAX(mu_0,lam*X(k)+(1-lam)*Z(k-1))
%Upper-sided EWMA chart
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function ARL=rluewmatbea(lam,UCL,disX,muX0,sdX0,disT,muT0,sdT0,rho1,rho2)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
r=100;
LCL=0.0028;
pr=2*r+1;
dr=(UCL-LCL)/(2*pr);
hr=linspace(LCL+dr,UCL-dr,pr);
hr=[LCL hr];
Hj=ones(pr+1,1)*hr;
Hi=Hj';
Q1=(Hj+dr-(1-lam)*Hi)/lam;
Q2=(Hj-dr-(1-lam)*Hi)/lam;
Q=cdfZ_Z1(Q1,disX,muX0,sdX0,disT,muT0,sdT0,rho1,rho2)-cdfZ_Z1(Q2,disX,muX0,sdX0,disT,muT0,sdT0,rho1,rho2);
Q(:,1)=cdfZ_Z1((LCL-(1-lam)*Hi(:,1))/lam,disX,muX0,sdX0,disT,muT0,sdT0,rho1,rho2);% 1the column is changed. 
q=zeros(pr+1,1);
q(1)=1;
W=inv(eye(pr+1,pr+1)-Q);
ARL=sum(q'*W);