function y = cdfZ_Z3(z, disX, muX0, sdX0, disT, muT0, sdT0, rho1, rho2) 
    y = zeros(size(z));
 [a,b]=size(z);
    for i = 1:a
        for j=1:b
                zi = z(i,j);
                integrand = @(x) cdfTX(muT0 ./ (zi - x), disT, rho2*muT0, sdT0) .* pdfTX(muX0 * x, disX, rho1*muX0, sdX0);
                y(i,j) = cdfTX(muX0 * zi, disX, rho1*muX0, sdX0) - muX0 * integral(integrand, eps, zi);
        end
    end