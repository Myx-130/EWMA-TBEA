function y = pdfZ_Z2(z, disX, muX0, muX1, sdX0, disT, muT0, muT1, sdT0)
    
    y = zeros(size(z));
    for i = 1:length(z)
                zi = z(i);
                integrand = @(x) x .* pdfTX(muT0 .* x / zi, disT, muT1, sdT0) .* pdfTX(muX0 * x, disX, muX1, sdX0);
                y(i) = muT0 * muX0 * (1/(zi)^2) * integral(integrand, eps, 10);
    end
end