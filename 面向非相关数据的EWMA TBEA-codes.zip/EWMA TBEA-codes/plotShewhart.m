clear; clc;
data0 = load('Shewhart.txt');
UCL = 1023.4721;

% 设置图表尺寸
figure('Position', [100 100 1200 700]); 

% 绘制数据点
x = 1:length(data0); 
plot(x, data0, 'o-', 'MarkerSize', 6, 'LineWidth', 1.2); 
hold on;

% 绘制UCL线（红色虚线）
plot([1, length(data0)], [UCL, UCL], 'r--', 'LineWidth', 1.2); 

% 添加UCL标签（非斜体，保留下标）
text(44, UCL - 30, '$\mathrm{UCL}_3 = 1023.4721$', ...
    'Interpreter', 'latex', ...
    'FontSize', 12, ...
    'HorizontalAlignment', 'center', ...
    'FontAngle', 'normal');  % 显式强制非斜体

% 坐标轴设置
set(gca, 'xlim', [1 max(x)], 'xtick', 1:5:max(x)); 
set(gca, 'ylim', [-10 1100], 'ytick', -10:50:1100); 
set(gca, 'box', 'off', 'TickDir', 'out'); 

% 坐标轴标签（LaTeX格式）
xlabel('$t$', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('$Z_t$', 'Interpreter', 'latex', 'FontSize', 12);

hold off;