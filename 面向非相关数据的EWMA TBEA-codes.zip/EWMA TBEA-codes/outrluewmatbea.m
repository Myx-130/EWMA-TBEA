clc;
clear;
tic;
lam=0.8;
UCL=0.3021;
rho1=[1 1.1 1.2 1.3 1.4 1.4 1.6 1.7 1.8 1.9 2];
rho2=[1 0.95 0.9 0.85 0.8 0.75 0.7 0.65 0.6 0.55 0.5];
ARL=zeros(length(lam),length(rho1),length(rho2));
for i=1:length(lam)
for p=1:length(rho1)
    for q=1:length(rho2)
    ARL(i,p,q)=rluewmatbea(lam(i),UCL(i),1,10,1,1,10,1,rho1(p),rho2(q))
    end
end
end
out=ARL;
toc;