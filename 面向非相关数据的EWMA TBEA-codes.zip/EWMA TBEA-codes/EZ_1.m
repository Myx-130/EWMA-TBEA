integrand = @(z)(z.*pdfZ_Z1(z, 1, 10.9211, 10.9211, 13.9793, 1, 5.5217, 5.5217, 6.9081));
Ez = integral(integrand, 1, 20);