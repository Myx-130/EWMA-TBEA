%%Fig
%gammax=gammay=0.01 rho0=rho1=-0.8 AEWMA Section 5.1 第三点简化图，转化为对数
tau=[1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2];
ARL1=[13.1847	4.505	2.712	2.002	1.6011	1.3038	1.1112	1.0278	1.0047	1.0005];
ARL2=[13.6316	5.7134	3.6681	2.7588	2.2565	1.9535	1.7408	1.544	1.3545	1.1997];
ARL3=[13.275	5.5486	3.5585	2.6732	2.1882	1.9398	1.7506	1.4926	1.2301	1.0683];
plot(tau,ARL1,'-ok',tau,ARL2,'-^k',tau,ARL3,'-dk');
hleg1=legend('$Z_1$','$Z_2$','$Z_3$','Interpreter','latex','FontSize',10);
xlabel('$\rho_x$','Interpreter','latex','FontSize',10);
ylabel('$\it ARL_{1}$','Interpreter','latex','FontSize',10);