function [] = RunOpttbeaLam()
    % 定义lam的值
    lam_values = [0.3 0.41];
    
    % 其他参数的固定值
    disX = 1; % 填入你的值
    muX0 = 10; % 填入你的值
    sdX0 = 1; % 填入你的值
    disT = 1; % 填入你的值
    muT0 = 10; % 填入你的值
    sdT0 = 1; % 填入你的值
    arl0 = 200; % 填入你的值
    
    % 启动并行池
    parpool('local');  
    
    % 并行计算
    parfor i = 1:length(lam_values)
        lam = lam_values(i);
        [UCLd, ARL0, flag] = OpttbeaLam(lam, disX, muX0, sdX0, disT, muT0, sdT0, arl0);
        fprintf('For lam = %.2f: UCLd = %.4f, ARL0 = %.4f, iterations = %d\n', lam, UCLd, ARL0, flag);
    end
    
    % 关闭并行池
    delete(gcp('nocreate'));
end

function [UCLd, ARL0, flag] = OpttbeaLam(lam, disX, muX0, sdX0, disT, muT0, sdT0, arl0)
    tor = 0.5;
    rho1 = 1;
    rho2 = 1;
    lb = 0.16;
    ub = 0.21;
    flag = 0;
    
    while true
        UCL = (lb + ub) / 2;
        ARL = rluewmatbea(lam, UCL, disX, muX0, sdX0, disT, muT0, sdT0, rho1, rho2);
        
        if (ARL < arl0 + tor) && (ARL > arl0 - tor)
            UCLd = UCL;
            ARL0 = ARL;
            break; 
        elseif ARL <= arl0 - tor
            lb = UCL;
        else
            ub = UCL;
        end
        
        flag = flag + 1;
        if flag > 50
            UCLd = UCL;
            ARL0 = ARL;
            break;
        end
    end
end