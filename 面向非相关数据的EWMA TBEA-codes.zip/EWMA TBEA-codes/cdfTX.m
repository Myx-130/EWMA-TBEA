function y = cdfTX(x, dis, mu, sd)
    % Check the number of input arguments
    % 1为Gamma分布
    % 2为Lognormal分布
    % 3为Normal分布
    % 4为Weibull分布
    % Weibull分布的两个参数位置相反
    narginchk(4, 4);
    assert(sd > 0, 'Argument ''sd'' must be > 0');
    
    [a, b] = abfrommusd(dis, mu, sd);
    switch dis
        case 1, y = cdf('gamma',   x, a, b);
        case 2, integrand = @(t) (b ./ t).*normpdf(a+b.*log(t));
                y= integral(integrand, 0, x);
        case 3, y = cdf('normal',  x, a, b);
        case 4, y = cdf('weibull', x, b, a);
    end
end