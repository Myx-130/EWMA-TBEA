function y = pdfZ_Z3(z, disX, muX0, muX1, sdX0, disT, muT0, muT1, sdT0)

y = zeros(size(z));
    for i = 1:length(z)
                zi = z(i);
                integrand = @(x) pdfTX(muT0 ./ (zi - x), disT, muT1, sdT0) .* pdfTX(muX0 * x, disX, muX1, sdX0) ./ (zi - x).^2;
                y(i) = muT0 * muX0 * integral(integrand, eps, zi);
    end
end