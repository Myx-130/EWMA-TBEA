% Excel 文件名
filename = 'Z1.xlsx';  % 你的 Excel 文件

%% 只读取第一个 sheet
T = readmatrix(filename,'Sheet',1);
X = T(1,2:end);         % 横坐标 X (1.1 到 2)
Y = T(2:end,1);         % 纵坐标 T (0.5 到 0.95)
Z = T(2:end,2:end);     % 数据矩阵 Z1

%% 创建单个图形窗口
figure('Position',[100,100, 800, 600]);  % 调整窗口大小

%% 绘制单个子图
% 转换为网格
[Xgrid,Ygrid] = meshgrid(X,Y);

% 手动指定等高线层级
minZ = min(Z(:));
maxZ = max(Z(:));
levels = [1, 1.1, 1.2, 1.5, 2, 2.5, 3, 4, 5, 6, 7];  % 自定义层级

% 绘制等高线图 - 全部使用黑色
[C, h] = contour(Xgrid,Ygrid,Z, levels, 'ShowText','on','LineWidth',1.5,'LineColor','k');

% 标签设置 - 全部使用黑色
clabel(C, h, 'FontSize', 9, 'FontWeight', 'bold', 'Color', 'k');

% 设置坐标轴和标题
xlabel('$\rho_x$','interpreter','latex','fontsize',14);
ylabel('$\rho_t$','interpreter','latex','fontsize',14);
title('$Z_3$','interpreter','latex','fontsize',16);

% 设置刻度和字体
set(gca,'FontSize',10, 'FontName', 'Arial');
set(gca,'Box','on','GridAlpha',0.3);

% 添加网格（浅色）
grid on;
set(gca,'GridColor',[0.8 0.8 0.8],'GridAlpha',0.3);

% 调整图形的纵横比
pbaspect([1.2 1 1]);  % 稍微调整宽高比

% 设置坐标轴范围（根据数据范围）
xlim([min(X) max(X)]);
ylim([min(Y) max(Y)]);