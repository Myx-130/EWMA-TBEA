function y = pdfTX(x, dis, mu, sd)
    % Check the number of input arguments
    % 1为Gamma分布
    % 2为Lognormal分布
    % 3为Normal分布
    % 4为Weibull分布
    % Weibull分布两个参数位置相反
    narginchk(4, 4);
    
    [a, b] = abfrommusd(dis, mu, sd);
    switch dis
        case 1, y = pdf('gamma',   x, a, b);
        case 2, y = (b./x).*normpdf(a+b.*log(x));
        case 3, y = pdf('normal',  x, a, b);
        case 4, y = pdf('weibull', x, b, a);
    end
end
