integrand = @(z)(z.*pdfZ_Z2(z, 1, 13.5781, 13.5781, 22.8687, 1, 5.4681, 5.4681, 6.8425));
Ez = integral(integrand, eps, 10);