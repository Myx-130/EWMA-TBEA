clc;
clear;
tic;
k=0.3;
UCL=0.0096;
rho1=[1 1.1 1.2 1.3 1.4 1.4 1.6 1.7 1.8 1.9 2];
rho2=[1 0.95 0.9 0.85 0.8 0.75 0.7 0.65 0.6 0.55 0.5];
ARL=zeros(length(k),length(rho1),length(rho2));
for i=1:length(k)
for p=1:length(rho1)
    for q=1:length(rho2)
    ARL(i,p,q)=rlucusumtbea(k(i),UCL(i),1,10,1,1,10,1,rho1(p),rho2(q))
    end
end
end
out=ARL;
toc;